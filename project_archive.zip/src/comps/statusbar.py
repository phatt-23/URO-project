from comps.component import Component


class StatusBar(Component):
    pass
